<?php 
    $dictamen = $_POST['dictamen'];

    $id_aut = $_POST['id_aut'];
  
       include 'bd_conexion.php';  
    $query = "UPDATE solicitud_autorizacion SET id_dictamen  = '$dictamen'  WHERE id_aut = '$id_aut'";
        $result = mysqli_query($conn,$query);
       if(mysqli_affected_rows($conn)>0) {
           header('location:../../view-solicitudes.php?result=success');
       } else {
           header('location:../../view-solicitudes.php?result=fail');
       }
                            
   ?>   