<?php
include_once 'bd_conexion.php';

?>