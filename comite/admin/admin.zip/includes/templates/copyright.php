<div class="float-right d-none d-sm-block">
      <b>Version</b> 1.0.0
    </div>
    <strong>Copyright &copy; 2022 <a href="https://oporfin.mx">Oporfin</a>.</strong> Todos los derechos Reservaods. OPORTUNIDADES FINANCIERAS PARA TU NEGOCIO, S.A. DE C.V. SOFOM ENR
