
<?php include_once 'includes/templates/header.php';?>
<?php include_once 'includes/templates/slide-bar.php';?>
<?php include_once 'includes/funciones/funciones.php';?>
<script src="sweet/dist/sweetalert2.min.js"></script>
<link rel="stylesheet" href="sweet/dist/sweetalert2.min.css">
<link rel="stylesheet" href="//cdn.datatables.net/1.10.15/css/jquery.dataTables.min.css"/>
<script src="//code.jquery.com/jquery-1.12.4.js"></script>
<script src="//cdn.datatables.net/1.10.15/js/jquery.dataTables.min.js"></script>
<script src="//cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css"></script>
<script src="//cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>

<style>
  .dt-buttons{
    padding:20px;
    display:flex;

  }
</style>
<?php

if(isset($_GET['result']  ))
{
if($_GET['result']=='success')
{
  
?>
<script> 
Swal.fire(
  'Listo!',
  'Operación Realizada con éxito',
  'success' )
  </script>;

<?php
}
else{
  ?>
  <script> 
  Swal.fire({
    icon: 'error',
    title: 'Error...',
    text: 'Algo Salio Mal al modificar el registro!',
    
  }) </script>;

<?php
  }
}
?>  
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
  <section class="content-header">
<div class="row">
<?php
	

	
  if($rol_id == 2) {?>
  <div class="col-md-3">
    <div class="card card-primary">
      <div class="card-header">
        <h3 class="card-title">Datos del Cliente</h3>

       
      </div>
      <form method="POST" name="crear-admin" id="crear-admin" action="insertar-sol.php">
          <div class="card-body">

          <div class="form-group">
              <label for="num">Número de Solicitud</label>
              <input type="number"  class="form-control" id="num" name="num" placeholder="NÚMERO DE SOLICITUD">
            </div>

          <div class="form-group">
          <select class="form-control col-md-12"" id="tipo" name="tipo">
         
                      <option selected> TIPO DE CRÉDITO</option>
                      <option value="SIMPLE">SIMPLE</option>
                      <option value="MICROCRÉDITO">MICROCRÉDITO</option>
                      <option value="PYME">PYME</option>
                    </select>

              <!--<label for="usuario">Usuario</label>
              <input type="text"  class="form-control" id="usuario" name="usuario" placeholder="Usuario"> -->
            </div>
            <div class="form-group">
           <select class="form-control col-md-12"" id="promotor" name="promotor">
         
         <option selected> PROMOTOR</option>
         <option value="ROSA OLVERA">ROSA OLVERA</option>
         <option value="PATRICIA CH">PATRICIA CH.</option>
         <option value="ANASTACIO A">ANASTACIO A.</option>
         <option value="DAVID P">DAVID P.</option>
       </select>

 <!--<label for="usuario">Usuario</label>
 <input type="text"  class="form-control" id="usuario" name="usuario" placeholder="Usuario"> -->
</div>
            <div class="form-group">
              <label for="nombre">Nombre</label>
              <input type="text"  class="form-control" id="nombre" name="nombre" placeholder="NOMBRE DEL CLIENTE">
            </div>
            <div class="form-group">
              <label for="Monto">Monto Solicitado</label>
              <input type="number"  class="form-control" id="Monto" name="monto" placeholder="MONTO SOLICITIADO">
            </div>
            <div class="form-group">
           <select class="form-control col-md-12" id="plazo" name="plazo">
         
         <option selected> SELECCIONA PLAZO</option>
         <option value="12 MESES">12 MESES</option>
         <option value="18 MESES">18 MESES</option>
         <option value="24 MESES">24 MESES</option>
         <option value="30 MESES">30 MESES</option>
         <option value="36 MESES">36 MESES</option>
         <option value="42 MESES">42 MESES</option>
         <option value="48 MESES">48 MESES</option>
         <option value="54 MESES">54 MESES</option>
         <option value="60 MESES">60 MESES</option>
         <option value="66 MESES">66 MESES</option>
         <option value="72 MESES">72 MESES</option>
         
       </select>

</div>
              <div class="form-group">
              <label for="tasa">Tasa</label>
              <input type="text"  class="form-control" id="tasa" name="tasa" placeholder="TASA DE INTERÉS">
            </div>
            <div class="form-group">
              <label for="comision">% Comisión</label>
              <input type="text"  class="form-control" id="comision" name="comision" placeholder="COMISIÓN POR APERTURA">
            </div>
            <div class="form-group">
              <label for="uso">Uso de Crédito</label>
              <input type="text" class="form-control" id="uso" name="uso" placeholder="DESTINO DEL CRÉDITO">
              </div>
              <div class="form-group">
              <label for="observaciones">Observaciones Analista</label>
              <textarea row="6"  class="form-control" id="observaciones" name="observaciones" placeholder="OBSERVACIONES"></textarea>
            </div>
            <div class="form-group">
            <select class="form-control col-md-12" id="dictamen" name="dictamen">
         
         <option selected> DICTAMEN</option>
         <option value="APROBADO">APROBADO</option>
         <option value="RECHAZADO">RECHAZADO</option>
         <option value="A CONSIDERACIÓN">A CONSIDERACIÓN</option>
        
         
       </select>
        </div>
        <div class="form-group">
            <select class="form-control col-md-12" id="analista" name="analista">
         
         <option selected> ANALISTA</option>
         <option value="RODRIGO BURGOS">RODRIGO BURGOS</option>
         <option value="ALFREDO MUÑIZ">ALFREDO MUÑIZ</option>
         
        
         
       </select>
        </div>


            </div>
           

            <!-- /.card-body -->
            <div class="card-footer">
              <input type="hidden" name="agregar-sol" value="1">
              <button type="submit" class="btn btn-primary">Agregar</button>
            </div>
          </form>
       
 
 </div></div>
       <?php }?>
 
      
        <!-- /.card -->



  <!-- /.tabla de lista de solicitudes -->

        <div class="col-md-9">
                  <!-- /.card -->
          <div class="card card-primary">
            <div class="card-header">
              <h3 class="card-title">Lista de Solicitudes</h3>

             
              </div>
            </div>
            <div class="card-body p-3">
            <table id="mitabla" class="table table-hover table-bordered">
                  <thead>
                      <tr>
                                <th hidden>a</th>
                                <th># Sol.</th>
                                <th>Nombre</th>
                                <th>Solicitado</th>
                                <th>Autorizado</th>
                                <th>Plazo</th>
                                <th>Dictamen</th>
                                <th>Acción</th>
                      </tr>
                  </thead>
                <tbody>
                       <!--Trae el listado de solicitudes -->          
                            <?php
                                            try {
                        $sql ="SELECT * FROM solicitud_autorizacion 
                        INNER JOIN dictamen ON solicitud_autorizacion.id_dictamen =dictamen.id_dictamen
                        WHERE id_status = 0
                        ORDER BY id_aut desc";
                        
                            $resultado = $conn->query($sql);
                      } catch (Exception $e) {
                        $error = $e->getMessage();
                      }
                        while($solicitud = $resultado->fetch_assoc()) {  ?>
                            <tr>    <!--imprime listado de solicitudes --> 
                              <td hidden><span  id="id_aut<?php echo $solicitud['id_aut'];?>"><?php echo $solicitud['id_aut']; ?><span></td >
                              <td><span id="num_sol<?php echo $solicitud['id_aut'];?>"><?php echo $solicitud['num_sol']; ?><span></td>
                              <td><span id="nombre<?php echo $solicitud['id_aut'];?>"><?php echo $solicitud['nombre']; ?><span></td>
                              <td><span id="monto_sol<?php echo $solicitud['id_aut'];?>"><?php echo $solicitud['monto_sol']; ?><span></td>
                              <td><span id="monto_aut<?php echo $solicitud['id_aut'];?>"><?php echo $solicitud['monto_aut']; ?><span></td>
                              <td><span id="plazo<?php echo $solicitud['id_aut'];?>"><?php echo $solicitud['plazo']; ?><span></td>
                              
                              <td> <?php if($rol_id == 1) {
                                              if($solicitud['id_dictamen'] ==0){
                                              ?>
                                              <button class="btn btn-secondary asignar" value="<?php echo $solicitud['id_aut']; ?>"> <?php echo "SIN DICTAMEN"; ?> </a>
                                              <?php 
                                              }else if($solicitud['id_dictamen'] ==1){
                                              ?><button class="btn btn-success asignar" value="<?php echo $solicitud['id_aut']; ?>"> <?php echo $solicitud['dictamen']; ?> </a>
                                              <?php 
                                              }else if($solicitud['id_dictamen'] ==3){
                                                ?><button class="btn btn-danger asignar" value="<?php echo $solicitud['id_aut']; ?>"> <?php echo $solicitud['dictamen']; ?> </a>
                                                <?php 
                                              }else if($solicitud['id_dictamen'] ==4){
                                                ?><button class="btn btn-warning asignar" value="<?php echo $solicitud['id_aut']; ?>"> <?php echo $solicitud['dictamen']; ?> </a>
                                                <?php 
                                              }
                                          ?>
                                      
                             <?php }?>
                             <?php if($rol_id == 2) {?>
                                    <?php   
                                              if($solicitud['id_dictamen'] ==0){
                                              ?>
                                              <button class="btn btn-secondary" value="<?php echo $solicitud['id_aut']; ?>"> <?php echo "SIN DICTAMEN"; ?> </a>
                                              <?php 
                                              }else if($solicitud['id_dictamen'] ==1){
                                              ?><button class="btn btn-success" value="<?php echo $solicitud['id_aut']; ?>"> <?php echo $solicitud['dictamen']; ?> </a>
                                              <?php 
                                              }else if($solicitud['id_dictamen'] ==3){
                                                ?><button class="btn btn-danger" value="<?php echo $solicitud['id_aut']; ?>"> <?php echo $solicitud['dictamen']; ?> </a>
                                                <?php 
                                              }else if($solicitud['id_dictamen'] ==4){
                                                ?><button class="btn btn-warning" value="<?php echo $solicitud['id_aut']; ?>"> <?php echo $solicitud['dictamen']; ?> </a>
                                                <?php 
                                              }
                                          ?>
                                     
                             <?php }?> 
                                    </td>
                                      <td>    
                                        <div class="float-left">
                                            <a href="perfil-solicitud.php?id_aut=<?php echo $solicitud['id_aut']; ?>" type="button" class="btn bg-yellow btn-flat margin"> <i class="far fa-eye" aria-hidden="true"></i> </a>
                                              <?php if($solicitud['id_dictamen'] ==0 && $rol_id == 2) {?> <a href="includes/funciones/delete-solicitud.php?id_aut=<?php echo $solicitud['id_aut'];?>" type="button" class="btn bg-red btn-flat margin" id="eliminar"> <i class="fas fa-trash" aria-hidden="true"></i> </a>
                                              <?php }  if($solicitud['id_dictamen'] ==1) {?><a href="autorizacion.php?id_aut=<?php echo $solicitud['id_aut']; ?>" type="button" class="btn bg-blue btn-flat margin"> <i class="fa fa-file-pdf" aria-hidden="true"></i> </a>
                                              <?php }?>
                                        </div>
                                    </td>
                             
                              </tr>  
                  <?php } ?>
                  
                </tbody>
         
           </table>
                              
      </div>  

<?php if($rol_id == 2) {?>
  <div class="col-md-12">
    <div class="card card-primary">
      <div class="card-header">
        <h3 class="card-title">Carga Masiva</h3>
        </diV>
        </diV>
      <form action="recibe_excel_validando.php" method="POST" enctype="multipart/form-data"/>
      <div>
            <input class="form-control form-control-lg" id="file-input" name="dataCliente" type="file">
        </div>

       <div>
</br>
           <input type="submit" name="subir" class="btn btn-primary" value="Subir Excel"/>
       </div>
       </form>
</diV>


<?php }?>
    <!-- /.content -->
  </div>
 
</div>
<!-- ./wrapper -->

<?php include_once ('modal_asignar.php');?>
<script src='js/modal.js'</script>
<?php include_once 'includes/templates/footer.php';?>

<script src="plugins/datatables/jquery.dataTables.min.js"></script>
<script src="plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
<script src="plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
<script src="plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
<script src="plugins/jszip/jszip.min.js"></script>
<script src="plugins/pdfmake/pdfmake.min.js"></script>
<script src="plugins/pdfmake/vfs_fonts.js"></script>
<script src="plugins/datatables-buttons/js/buttons.html5.min.js"></script>
<script src="plugins/datatables-buttons/js/buttons.print.min.js"></script>
<script src="plugins/datatables-buttons/js/buttons.colVis.min.js"></script>
<script src="plugins/jsgrid/demos/db.js"></script>
<script src="plugins/jsgrid/jsgrid.min.js"></script>
<script src="plugins/traduccion.js"></script>
<script>let table = new DataTable('#mitabla');</script>

