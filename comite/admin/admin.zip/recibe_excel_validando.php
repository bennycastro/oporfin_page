<?php
require('includes/funciones/bd_conexion.php');
$tipo       = $_FILES['dataCliente']['type'];
$tamanio    = $_FILES['dataCliente']['size'];
$archivotmp = $_FILES['dataCliente']['tmp_name'];
$lineas     = file($archivotmp);

$i = 0;

foreach ($lineas as $linea) {
    $cantidad_registros = count($lineas);
    $cantidad_regist_agregados =  ($cantidad_registros - 1);

    if ($i != 0) {

        $datos = explode(",", $linea);
        $num_sol	         = !empty($datos[0])  ? ($datos[0]) : '';
        $nombre	         = !empty($datos[1])  ? ($datos[1]) : '';
        $monto_sol	         = !empty($datos[2])  ? ($datos[2]) : '';
        $monto_aut      	 = !empty($datos[3])  ? ($datos[3]) : '';
        $plazo	             = !empty($datos[4])  ? ($datos[4]) : '';
        $tasa	             = !empty($datos[5])  ? ($datos[5]) : '';
        $comision	         = !empty($datos[6])  ? ($datos[6]) : '';
        $promotor	         = !empty($datos[7])  ? ($datos[7]) : '';
        $observaciones_analista		 = !empty($datos[8])  ? ($datos[8]) : '';
        $uso_cred	         = !empty($datos[9])  ? ($datos[9]) : '';
        $tipo_credito   	 = !empty($datos[10])  ? ($datos[10]) : '';
        $dictamen_analista	 = !empty($datos[11])  ? ($datos[11]) : '';
        $analista            = !empty($datos[12])  ? ($datos[12]) : '';

       
  
    $insertar = "INSERT INTO solicitud_autorizacion( 
        num_sol,
            nombre,
            monto_sol,
			plazo,
            tasa,
			comision,
            promotor,
            observaciones_analista,
			uso_cred,
            tipo_credito,
            dictamen_analista,
            analista
        ) VALUES(
            '$num_sol',
            '$nombre',
            '$monto_sol',
			'$plazo',
            '$tasa',
			'$comision',
            '$promotor',
            '$observaciones_analista',
			'$uso_cred',
            '$tipo_credito',
            '$dictamen_analista',
            '$analista'
        )";
        mysqli_query($conn, $insertar);
    }

      echo '<div>'. $i. "). " .$linea.'</div>';
    $i++;
}



  if($i>0) {
    header('location:view-solicitudes.php?result=success');
    
} else {
   header('location:view-solicitudes.php?result=fail');
}
?>


